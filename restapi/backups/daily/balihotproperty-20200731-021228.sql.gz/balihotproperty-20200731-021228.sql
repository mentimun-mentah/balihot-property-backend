--
-- PostgreSQL database dump
--

-- Dumped from database version 12.3 (Debian 12.3-1.pgdg100+1)
-- Dumped by pg_dump version 12.2 (Debian 12.2-2.pgdg100+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: balihotproperty
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO balihotproperty;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: balihotproperty
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: balihotproperty
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO balihotproperty;

--
-- Name: confirmation_users; Type: TABLE; Schema: public; Owner: balihotproperty
--

CREATE TABLE public.confirmation_users (
    id character varying(100) NOT NULL,
    activated boolean,
    resend_expired integer,
    user_id integer NOT NULL
);


ALTER TABLE public.confirmation_users OWNER TO balihotproperty;

--
-- Name: facilities; Type: TABLE; Schema: public; Owner: balihotproperty
--

CREATE TABLE public.facilities (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    icon character varying(40) NOT NULL
);


ALTER TABLE public.facilities OWNER TO balihotproperty;

--
-- Name: facilities_id_seq; Type: SEQUENCE; Schema: public; Owner: balihotproperty
--

CREATE SEQUENCE public.facilities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.facilities_id_seq OWNER TO balihotproperty;

--
-- Name: facilities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: balihotproperty
--

ALTER SEQUENCE public.facilities_id_seq OWNED BY public.facilities.id;


--
-- Name: password_resets; Type: TABLE; Schema: public; Owner: balihotproperty
--

CREATE TABLE public.password_resets (
    id character varying(100) NOT NULL,
    email character varying(100) NOT NULL,
    resend_expired integer,
    created_at timestamp without time zone
);


ALTER TABLE public.password_resets OWNER TO balihotproperty;

--
-- Name: properties; Type: TABLE; Schema: public; Owner: balihotproperty
--

CREATE TABLE public.properties (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    slug text NOT NULL,
    images text NOT NULL,
    property_for character varying(15) NOT NULL,
    period character varying(50),
    status character varying(30),
    youtube character varying(100) NOT NULL,
    description text NOT NULL,
    hotdeal boolean,
    bedroom integer,
    bathroom integer,
    building_size integer,
    land_size integer NOT NULL,
    location text NOT NULL,
    latitude double precision NOT NULL,
    longitude double precision NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    type_id integer NOT NULL,
    region_id integer NOT NULL
);


ALTER TABLE public.properties OWNER TO balihotproperty;

--
-- Name: properties_id_seq; Type: SEQUENCE; Schema: public; Owner: balihotproperty
--

CREATE SEQUENCE public.properties_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.properties_id_seq OWNER TO balihotproperty;

--
-- Name: properties_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: balihotproperty
--

ALTER SEQUENCE public.properties_id_seq OWNED BY public.properties.id;


--
-- Name: property_facilities; Type: TABLE; Schema: public; Owner: balihotproperty
--

CREATE TABLE public.property_facilities (
    id integer NOT NULL,
    property_id integer NOT NULL,
    facility_id integer NOT NULL
);


ALTER TABLE public.property_facilities OWNER TO balihotproperty;

--
-- Name: property_facilities_id_seq; Type: SEQUENCE; Schema: public; Owner: balihotproperty
--

CREATE SEQUENCE public.property_facilities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.property_facilities_id_seq OWNER TO balihotproperty;

--
-- Name: property_facilities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: balihotproperty
--

ALTER SEQUENCE public.property_facilities_id_seq OWNED BY public.property_facilities.id;


--
-- Name: property_prices; Type: TABLE; Schema: public; Owner: balihotproperty
--

CREATE TABLE public.property_prices (
    id integer NOT NULL,
    freehold_price integer,
    leasehold_price integer,
    leasehold_period character varying(40),
    daily_price integer,
    weekly_price integer,
    monthly_price integer,
    annually_price integer,
    property_id integer NOT NULL
);


ALTER TABLE public.property_prices OWNER TO balihotproperty;

--
-- Name: property_prices_id_seq; Type: SEQUENCE; Schema: public; Owner: balihotproperty
--

CREATE SEQUENCE public.property_prices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.property_prices_id_seq OWNER TO balihotproperty;

--
-- Name: property_prices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: balihotproperty
--

ALTER SEQUENCE public.property_prices_id_seq OWNED BY public.property_prices.id;


--
-- Name: regions; Type: TABLE; Schema: public; Owner: balihotproperty
--

CREATE TABLE public.regions (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    image character varying(100) NOT NULL
);


ALTER TABLE public.regions OWNER TO balihotproperty;

--
-- Name: regions_id_seq; Type: SEQUENCE; Schema: public; Owner: balihotproperty
--

CREATE SEQUENCE public.regions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.regions_id_seq OWNER TO balihotproperty;

--
-- Name: regions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: balihotproperty
--

ALTER SEQUENCE public.regions_id_seq OWNED BY public.regions.id;


--
-- Name: teams; Type: TABLE; Schema: public; Owner: balihotproperty
--

CREATE TABLE public.teams (
    id integer NOT NULL,
    image character varying(100) NOT NULL,
    name character varying(100) NOT NULL,
    title character varying(100) NOT NULL,
    phone character varying(20) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.teams OWNER TO balihotproperty;

--
-- Name: teams_id_seq; Type: SEQUENCE; Schema: public; Owner: balihotproperty
--

CREATE SEQUENCE public.teams_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.teams_id_seq OWNER TO balihotproperty;

--
-- Name: teams_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: balihotproperty
--

ALTER SEQUENCE public.teams_id_seq OWNED BY public.teams.id;


--
-- Name: types; Type: TABLE; Schema: public; Owner: balihotproperty
--

CREATE TABLE public.types (
    id integer NOT NULL,
    name character varying(100) NOT NULL
);


ALTER TABLE public.types OWNER TO balihotproperty;

--
-- Name: types_id_seq; Type: SEQUENCE; Schema: public; Owner: balihotproperty
--

CREATE SEQUENCE public.types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.types_id_seq OWNER TO balihotproperty;

--
-- Name: types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: balihotproperty
--

ALTER SEQUENCE public.types_id_seq OWNED BY public.types.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: balihotproperty
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(100) NOT NULL,
    email character varying(100) NOT NULL,
    password character varying(100),
    role integer,
    avatar character varying(100),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.users OWNER TO balihotproperty;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: balihotproperty
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO balihotproperty;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: balihotproperty
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: visits; Type: TABLE; Schema: public; Owner: balihotproperty
--

CREATE TABLE public.visits (
    id integer NOT NULL,
    ip character varying(20) NOT NULL,
    visitable_id integer NOT NULL,
    visitable_type character varying(30) NOT NULL,
    created_at timestamp without time zone
);


ALTER TABLE public.visits OWNER TO balihotproperty;

--
-- Name: visits_id_seq; Type: SEQUENCE; Schema: public; Owner: balihotproperty
--

CREATE SEQUENCE public.visits_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.visits_id_seq OWNER TO balihotproperty;

--
-- Name: visits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: balihotproperty
--

ALTER SEQUENCE public.visits_id_seq OWNED BY public.visits.id;


--
-- Name: wishlists; Type: TABLE; Schema: public; Owner: balihotproperty
--

CREATE TABLE public.wishlists (
    id integer NOT NULL,
    property_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.wishlists OWNER TO balihotproperty;

--
-- Name: wishlists_id_seq; Type: SEQUENCE; Schema: public; Owner: balihotproperty
--

CREATE SEQUENCE public.wishlists_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.wishlists_id_seq OWNER TO balihotproperty;

--
-- Name: wishlists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: balihotproperty
--

ALTER SEQUENCE public.wishlists_id_seq OWNED BY public.wishlists.id;


--
-- Name: facilities id; Type: DEFAULT; Schema: public; Owner: balihotproperty
--

ALTER TABLE ONLY public.facilities ALTER COLUMN id SET DEFAULT nextval('public.facilities_id_seq'::regclass);


--
-- Name: properties id; Type: DEFAULT; Schema: public; Owner: balihotproperty
--

ALTER TABLE ONLY public.properties ALTER COLUMN id SET DEFAULT nextval('public.properties_id_seq'::regclass);


--
-- Name: property_facilities id; Type: DEFAULT; Schema: public; Owner: balihotproperty
--

ALTER TABLE ONLY public.property_facilities ALTER COLUMN id SET DEFAULT nextval('public.property_facilities_id_seq'::regclass);


--
-- Name: property_prices id; Type: DEFAULT; Schema: public; Owner: balihotproperty
--

ALTER TABLE ONLY public.property_prices ALTER COLUMN id SET DEFAULT nextval('public.property_prices_id_seq'::regclass);


--
-- Name: regions id; Type: DEFAULT; Schema: public; Owner: balihotproperty
--

ALTER TABLE ONLY public.regions ALTER COLUMN id SET DEFAULT nextval('public.regions_id_seq'::regclass);


--
-- Name: teams id; Type: DEFAULT; Schema: public; Owner: balihotproperty
--

ALTER TABLE ONLY public.teams ALTER COLUMN id SET DEFAULT nextval('public.teams_id_seq'::regclass);


--
-- Name: types id; Type: DEFAULT; Schema: public; Owner: balihotproperty
--

ALTER TABLE ONLY public.types ALTER COLUMN id SET DEFAULT nextval('public.types_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: balihotproperty
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: visits id; Type: DEFAULT; Schema: public; Owner: balihotproperty
--

ALTER TABLE ONLY public.visits ALTER COLUMN id SET DEFAULT nextval('public.visits_id_seq'::regclass);


--
-- Name: wishlists id; Type: DEFAULT; Schema: public; Owner: balihotproperty
--

ALTER TABLE ONLY public.wishlists ALTER COLUMN id SET DEFAULT nextval('public.wishlists_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: balihotproperty
--

COPY public.alembic_version (version_num) FROM stdin;
5de39c653ecc
\.


--
-- Data for Name: confirmation_users; Type: TABLE DATA; Schema: public; Owner: balihotproperty
--

COPY public.confirmation_users (id, activated, resend_expired, user_id) FROM stdin;
97b14655774b45d3ad307dbb4eccc1b0	t	\N	2
\.


--
-- Data for Name: facilities; Type: TABLE DATA; Schema: public; Owner: balihotproperty
--

COPY public.facilities (id, name, icon) FROM stdin;
1	asd	fa fa-user-alt
2	asd2	fa fa-user-alt2
3	asd3	fa fa-user-alt3
\.


--
-- Data for Name: password_resets; Type: TABLE DATA; Schema: public; Owner: balihotproperty
--

COPY public.password_resets (id, email, resend_expired, created_at) FROM stdin;
\.


--
-- Data for Name: properties; Type: TABLE DATA; Schema: public; Owner: balihotproperty
--

COPY public.properties (id, name, slug, images, property_for, period, status, youtube, description, hotdeal, bedroom, bathroom, building_size, land_size, location, latitude, longitude, created_at, updated_at, type_id, region_id) FROM stdin;
1	test-nama2	test-nama2	ced6223b0afc4374a0958e2badefb96f.jpeg,29994b6cd8fd4c4aac828eced565536a.jpeg,cc2411e62e024af384dd9ed0dbcff966.jpeg,1e5f8d4e64044f1bbf87cf145ae384f9.png,2978d7df5f494b298934b5c360933165.png	sale	\N	lease hold	https://www.youtube.com/watch?v=GdJP11JwLos	asd	f	1	1	1	1	asdasd	123	123	2020-07-31 02:05:03.821431	2020-07-31 02:05:03.821445	1	1
\.


--
-- Data for Name: property_facilities; Type: TABLE DATA; Schema: public; Owner: balihotproperty
--

COPY public.property_facilities (id, property_id, facility_id) FROM stdin;
1	1	1
2	1	2
3	1	3
\.


--
-- Data for Name: property_prices; Type: TABLE DATA; Schema: public; Owner: balihotproperty
--

COPY public.property_prices (id, freehold_price, leasehold_price, leasehold_period, daily_price, weekly_price, monthly_price, annually_price, property_id) FROM stdin;
1	\N	1	29 february 2020	\N	\N	\N	\N	1
\.


--
-- Data for Name: regions; Type: TABLE DATA; Schema: public; Owner: balihotproperty
--

COPY public.regions (id, name, image) FROM stdin;
1	dwqqasdasd	ed7158f61d62465b968d9d56fab85753.jpeg
\.


--
-- Data for Name: teams; Type: TABLE DATA; Schema: public; Owner: balihotproperty
--

COPY public.teams (id, image, name, title, phone, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: types; Type: TABLE DATA; Schema: public; Owner: balihotproperty
--

COPY public.types (id, name) FROM stdin;
1	Villa
2	Land
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: balihotproperty
--

COPY public.users (id, username, email, password, role, avatar, created_at, updated_at) FROM stdin;
2	asdasd	asdasd@gmail.com	$2b$12$KWvn.Fa7qSuNHig5LToMTuG7hMIATmcrK4sZ1iu.rR8LpS5pyReWG	2	default.png	2020-07-31 02:03:04.865604	2020-07-31 02:03:04.86562
\.


--
-- Data for Name: visits; Type: TABLE DATA; Schema: public; Owner: balihotproperty
--

COPY public.visits (id, ip, visitable_id, visitable_type, created_at) FROM stdin;
\.


--
-- Data for Name: wishlists; Type: TABLE DATA; Schema: public; Owner: balihotproperty
--

COPY public.wishlists (id, property_id, user_id) FROM stdin;
\.


--
-- Name: facilities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: balihotproperty
--

SELECT pg_catalog.setval('public.facilities_id_seq', 3, true);


--
-- Name: properties_id_seq; Type: SEQUENCE SET; Schema: public; Owner: balihotproperty
--

SELECT pg_catalog.setval('public.properties_id_seq', 1, true);


--
-- Name: property_facilities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: balihotproperty
--

SELECT pg_catalog.setval('public.property_facilities_id_seq', 3, true);


--
-- Name: property_prices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: balihotproperty
--

SELECT pg_catalog.setval('public.property_prices_id_seq', 1, true);


--
-- Name: regions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: balihotproperty
--

SELECT pg_catalog.setval('public.regions_id_seq', 1, true);


--
-- Name: teams_id_seq; Type: SEQUENCE SET; Schema: public; Owner: balihotproperty
--

SELECT pg_catalog.setval('public.teams_id_seq', 1, false);


--
-- Name: types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: balihotproperty
--

SELECT pg_catalog.setval('public.types_id_seq', 2, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: balihotproperty
--

SELECT pg_catalog.setval('public.users_id_seq', 2, true);


--
-- Name: visits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: balihotproperty
--

SELECT pg_catalog.setval('public.visits_id_seq', 1, false);


--
-- Name: wishlists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: balihotproperty
--

SELECT pg_catalog.setval('public.wishlists_id_seq', 1, false);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: balihotproperty
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: confirmation_users confirmation_users_pkey; Type: CONSTRAINT; Schema: public; Owner: balihotproperty
--

ALTER TABLE ONLY public.confirmation_users
    ADD CONSTRAINT confirmation_users_pkey PRIMARY KEY (id);


--
-- Name: facilities facilities_pkey; Type: CONSTRAINT; Schema: public; Owner: balihotproperty
--

ALTER TABLE ONLY public.facilities
    ADD CONSTRAINT facilities_pkey PRIMARY KEY (id);


--
-- Name: password_resets password_resets_pkey; Type: CONSTRAINT; Schema: public; Owner: balihotproperty
--

ALTER TABLE ONLY public.password_resets
    ADD CONSTRAINT password_resets_pkey PRIMARY KEY (id);


--
-- Name: properties properties_pkey; Type: CONSTRAINT; Schema: public; Owner: balihotproperty
--

ALTER TABLE ONLY public.properties
    ADD CONSTRAINT properties_pkey PRIMARY KEY (id);


--
-- Name: property_facilities property_facilities_pkey; Type: CONSTRAINT; Schema: public; Owner: balihotproperty
--

ALTER TABLE ONLY public.property_facilities
    ADD CONSTRAINT property_facilities_pkey PRIMARY KEY (id);


--
-- Name: property_prices property_prices_pkey; Type: CONSTRAINT; Schema: public; Owner: balihotproperty
--

ALTER TABLE ONLY public.property_prices
    ADD CONSTRAINT property_prices_pkey PRIMARY KEY (id);


--
-- Name: regions regions_pkey; Type: CONSTRAINT; Schema: public; Owner: balihotproperty
--

ALTER TABLE ONLY public.regions
    ADD CONSTRAINT regions_pkey PRIMARY KEY (id);


--
-- Name: teams teams_pkey; Type: CONSTRAINT; Schema: public; Owner: balihotproperty
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_pkey PRIMARY KEY (id);


--
-- Name: types types_pkey; Type: CONSTRAINT; Schema: public; Owner: balihotproperty
--

ALTER TABLE ONLY public.types
    ADD CONSTRAINT types_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: balihotproperty
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: visits visits_pkey; Type: CONSTRAINT; Schema: public; Owner: balihotproperty
--

ALTER TABLE ONLY public.visits
    ADD CONSTRAINT visits_pkey PRIMARY KEY (id);


--
-- Name: wishlists wishlists_pkey; Type: CONSTRAINT; Schema: public; Owner: balihotproperty
--

ALTER TABLE ONLY public.wishlists
    ADD CONSTRAINT wishlists_pkey PRIMARY KEY (id);


--
-- Name: ix_facilities_icon; Type: INDEX; Schema: public; Owner: balihotproperty
--

CREATE UNIQUE INDEX ix_facilities_icon ON public.facilities USING btree (icon);


--
-- Name: ix_facilities_name; Type: INDEX; Schema: public; Owner: balihotproperty
--

CREATE UNIQUE INDEX ix_facilities_name ON public.facilities USING btree (name);


--
-- Name: ix_password_resets_email; Type: INDEX; Schema: public; Owner: balihotproperty
--

CREATE UNIQUE INDEX ix_password_resets_email ON public.password_resets USING btree (email);


--
-- Name: ix_properties_name; Type: INDEX; Schema: public; Owner: balihotproperty
--

CREATE UNIQUE INDEX ix_properties_name ON public.properties USING btree (name);


--
-- Name: ix_regions_name; Type: INDEX; Schema: public; Owner: balihotproperty
--

CREATE UNIQUE INDEX ix_regions_name ON public.regions USING btree (name);


--
-- Name: ix_teams_name; Type: INDEX; Schema: public; Owner: balihotproperty
--

CREATE UNIQUE INDEX ix_teams_name ON public.teams USING btree (name);


--
-- Name: ix_types_name; Type: INDEX; Schema: public; Owner: balihotproperty
--

CREATE UNIQUE INDEX ix_types_name ON public.types USING btree (name);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: balihotproperty
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: balihotproperty
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: confirmation_users confirmation_users_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: balihotproperty
--

ALTER TABLE ONLY public.confirmation_users
    ADD CONSTRAINT confirmation_users_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: properties properties_region_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: balihotproperty
--

ALTER TABLE ONLY public.properties
    ADD CONSTRAINT properties_region_id_fkey FOREIGN KEY (region_id) REFERENCES public.regions(id);


--
-- Name: properties properties_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: balihotproperty
--

ALTER TABLE ONLY public.properties
    ADD CONSTRAINT properties_type_id_fkey FOREIGN KEY (type_id) REFERENCES public.types(id);


--
-- Name: property_facilities property_facilities_facility_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: balihotproperty
--

ALTER TABLE ONLY public.property_facilities
    ADD CONSTRAINT property_facilities_facility_id_fkey FOREIGN KEY (facility_id) REFERENCES public.facilities(id) ON DELETE CASCADE;


--
-- Name: property_facilities property_facilities_property_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: balihotproperty
--

ALTER TABLE ONLY public.property_facilities
    ADD CONSTRAINT property_facilities_property_id_fkey FOREIGN KEY (property_id) REFERENCES public.properties(id) ON DELETE CASCADE;


--
-- Name: property_prices property_prices_property_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: balihotproperty
--

ALTER TABLE ONLY public.property_prices
    ADD CONSTRAINT property_prices_property_id_fkey FOREIGN KEY (property_id) REFERENCES public.properties(id);


--
-- Name: wishlists wishlists_property_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: balihotproperty
--

ALTER TABLE ONLY public.wishlists
    ADD CONSTRAINT wishlists_property_id_fkey FOREIGN KEY (property_id) REFERENCES public.properties(id) ON DELETE CASCADE;


--
-- Name: wishlists wishlists_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: balihotproperty
--

ALTER TABLE ONLY public.wishlists
    ADD CONSTRAINT wishlists_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

